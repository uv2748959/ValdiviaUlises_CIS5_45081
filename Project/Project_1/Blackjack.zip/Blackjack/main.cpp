/* 
 * File:   main.cpp
 * Author: Ulises Valdivia
 * Created on July 14th, 2018, 3:34 PM
 * Purpose:  Blackjack
 *           Write a program that plays blackjack with a dealer.
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
#include <iomanip>  //Format Library
#include <ctime>
#include <cmath>
#include <string>
using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes

//Execution Begins Here!

void shuffle(bool baCardsDealt []);
void printcard (int iCard);
void printhand (int iaHand[], const int kiCardCount);
int getnextcard (bool baCardsDealt[]);
int scorehand (int iaHand [], const int kiCardCount);
void printscoresandhands (int iaDealerHand[], const int kiDealerCard, int iaPlayerhand [], const int kiPlayerCardCount);

int main(int argc, char** argv) 

{
    //Declare Variables

    time_t qTime;
    time (&qTime);
    srand (qTime);
    
    bool baCardsDealt [52];
    int iHouseCardCount=0;
    int iaDealerHand[12];
    int iPlayerCardCount=0;
    int iaPlayerHand[12];
    
    while (true)
    {
        shuffle (baCardsDealt);
        iaPlayerHand[0] = getnextcard(baCardsDealt);
        iaDealerHand[0] = getnextcard (baCardsDealt);
        iaPlayerHand[1] = getnextcard (baCardsDealt);
        iaDealerHand[1] = getnextcard (baCardsDealt);
        iHouseCardCount = 2;
        iPlayerCardCount = 2;
        
        cout << "NEW HAND" << endl;
        
        char cPlayerChoice;
        bool bPlayerHits = true;
        int iPlayerScore = scorehand (iaPlayerHand, iPlayerCardCount);
        
        do
        {
            cout << "Dealer's Hand" << endl;
            cout << "** ";
            printcard(iaDealerHand[1]);
            cout << endl;
            cout << "Player's Hand: Score = " << scorehand(iaPlayerHand, iPlayerCardCount) << endl;
            printhand(iaPlayerHand, iPlayerCardCount);
            
            cout << "Hit (h) or pass(p): ";
            cin >> cPlayerChoice;
            if (cPlayerChoice == 'h') 
            {
                iaPlayerHand [iPlayerCardCount] = getnextcard (baCardsDealt);
                ++iPlayerCardCount;
            }
            else if (cPlayerChoice == 'p')
            {
                bPlayerHits = false;
            }
            else
            {
                cout << "Error: Try Again..." << endl;
            }
            cout << endl;
            
            iPlayerScore = scorehand(iaPlayerHand, iPlayerCardCount);
        }
        while (bPlayerHits && iPlayerScore < 22);
        
        if (iPlayerScore > 21)
        {
            cout << "The Dealer Wins..." << endl;
            printscoresandhands (iaDealerHand, iHouseCardCount, iaPlayerHand, iPlayerCardCount);
        }
        else
        {
            int iHouseScore = scorehand (iaDealerHand, iHouseCardCount);
            while (iHouseScore < 17)
            {
                iaDealerHand[iHouseCardCount] = getnextcard(baCardsDealt);
                ++iHouseCardCount;
                iHouseScore = scorehand (iaDealerHand, iHouseCardCount);
            }
            bool bHouseBusts = (iHouseScore > 21);
            if (bHouseBusts)
            {
                cout << "The Player WINS !" << endl;
                printscoresandhands (iaDealerHand, iHouseCardCount, iaPlayerHand, iPlayerCardCount);
            }
            else
            {
                if (iPlayerScore == iHouseScore)
                {
                    cout << "TIE" << endl;
                    printscoresandhands (iaDealerHand, iHouseCardCount, iaPlayerHand, iPlayerCardCount);
                }
                else if (iPlayerScore > iHouseScore)
                {
                    cout << "The Player WINS !" << endl;
                    printscoresandhands (iaDealerHand, iHouseCardCount, iaPlayerHand, iPlayerCardCount);
                    
                }
                else 
                {
                    cout << "The Dealer Wins..." << endl;
                    printscoresandhands (iaDealerHand, iHouseCardCount, iaPlayerHand, iPlayerCardCount);
                    
                }
            }
        }
    }
    //Initial Variables

    //Map/Process Inputs to Outputs

    //Exit program!
    return EXIT_SUCCESS;
}

void shuffle (bool baCardsDealt [])
{
    for (int iIndex = 0; iIndex < 52; ++iIndex)
    {
        baCardsDealt [iIndex] = false;
    }
}

void printcard (int iCard)
{
    using namespace std;
    const int kiRank = (iCard % 13);
    if (kiRank == 0)
    {
        cout << 'A';
    }
    else if (kiRank < 9)
    {
        cout << (kiRank + 1);
    }
    else if (kiRank == 9)
    {
        cout << 'T';
    }
    else if (kiRank == 10)
    {
        cout << 'J';
    }
    else if (kiRank == 11)
    {
        cout << 'Q';
    }
    else 
    {
        cout << 'K';
    }
    
    const int kiSuit = (iCard/13);
    if (kiSuit == 0)
    {
        cout << 'C';
    }
    else if (kiSuit == 1)
    {
        cout << 'D';
    }
    else if (kiSuit == 2)
    {
        cout << 'H';
    }
    else 
    {
        cout << 'S';
    }
}

void printhand (int iaHand [], const int kiCardCount)
{
    using namespace std;
    for (int iCardIndex = 0; iCardIndex < kiCardCount; ++iCardIndex)
    {
        const int kiNextCard = iaHand[iCardIndex];
        printcard (kiNextCard);
        cout << "  ";
    }
    cout << endl;
}

int getnextcard (bool baCardsDealt [])
{
    bool bCardsDealt = true;
    int iNewCard = -1;
    do 
    {
        iNewCard = (rand() % 52);
        if (!baCardsDealt[iNewCard])
        {
            bCardsDealt = false;
        }
    }
    while (bCardsDealt);
    return iNewCard;
}

int scorehand (int iaHand[], const int kiCardCount)
{
    int iAceCount = 0;
    int iScore = 0;
    for (int iCardIndex = 0; iCardIndex < kiCardCount; ++iCardIndex)
    {
        const int kiNextCard = iaHand [iCardIndex];
        const int kiRank = (kiNextCard % 13);
        if (kiRank == 0)
        {
            ++iAceCount;
            ++iScore;
        }
        else if (kiRank < 9)
        {
            iScore = iScore + (kiRank + 1);
        }
        else 
        {
            iScore = iScore + 10;
        }
    }
    while (iAceCount > 0 && iScore < 12)
    {
        --iAceCount;
        iScore = iScore + 10;
    }
    return iScore;
}

void printscoresandhands (int iaHouseHand[], const int kiHouseCardCount, int iaPlayerHand[], const int kiPlayerCardCount)
{
    using namespace std;
    cout << "Dealer's Hand: Score = " << scorehand(iaHouseHand, kiHouseCardCount) << endl;
    printhand(iaHouseHand, kiHouseCardCount);
    cout << "Player's Hand: Score = " << scorehand(iaPlayerHand, kiPlayerCardCount) << endl;
    printhand(iaPlayerHand, kiPlayerCardCount);
    cout << endl;
}